u16 cp437_to_unicode(u8 cp437);
